@echo off
setlocal DisableDelayedExpansion
title Docker + WSL2 - diagnostyka i konfiguracja
set "WSL_SETUP_SELF=%~f0"
set "WSL_SETUP_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "WSL_SETUP_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%WSL_SETUP_PS%" -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:WSL_SETUP_SELF); $m='#'+' POWERSHELL_PAYLOAD'; & ([scriptblock]::Create($s.Substring($s.IndexOf($m)+$m.Length)))"
set "WSL_SETUP_EXIT=%ERRORLEVEL%"
echo.
if not "%WSL_SETUP_EXIT%"=="0" echo Konfiguracja nie zostala zakonczona. Kod: %WSL_SETUP_EXIT%
pause
exit /b %WSL_SETUP_EXIT%
# POWERSHELL_PAYLOAD
$ErrorActionPreference = 'Stop'

function Say([string]$Text) { Write-Host $Text }

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return ([Security.Principal.WindowsPrincipal]::new($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-PendingRestart {
    # Component servicing / Windows Update; no stale custom phase marker.
    return ((Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or
            (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'))
}

function Restart-Advice {
    Say ''
    Say '[RESTART] Zapisz prace i wybierz w Windows: Uruchom ponownie.'
    Say 'Po restarcie uruchom ponownie TEN SAM plik BAT.'
    Say 'Skrypt sprawdzi rzeczywisty stan systemu od poczatku.'
    Say 'Komputer nie zostanie zrestartowany automatycznie.'
}

function Invoke-Wsl([string[]]$Arguments, [int]$TimeoutSeconds = 300) {
    Say ''
    Say ('> wsl.exe ' + ($Arguments -join ' '))
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = Join-Path $env:SystemRoot 'System32\wsl.exe'
    $psi.Arguments = $Arguments -join ' '
    $psi.UseShellExecute = $false
    if ($Arguments -contains '--install' -or $Arguments -contains '--update') {
        # Inherit the console and all three standard handles. The WSL bootstrapper
        # must be able to read confirmations, just like a command typed in CMD.
        $psi.CreateNoWindow = $false
        $psi.RedirectStandardInput = $false
        $psi.RedirectStandardOutput = $false
        $psi.RedirectStandardError = $false
        Say 'Tryb interaktywny: potwierdz komunikaty instalatora, jesli sie pojawia.'
        Say 'Czekam na zakonczenie. Instalacja nie ma automatycznego limitu czasu.'
        Say 'Log zapisze polecenie i kod wyniku; komunikaty instalatora moga byc widoczne tylko w tym oknie.'
        $installer = New-Object Diagnostics.Process
        $installer.StartInfo = $psi
        try {
            if (-not $installer.Start()) { throw 'Nie udalo sie uruchomic instalatora WSL.' }
            $installer.WaitForExit()
            $code = $installer.ExitCode
            Say ('Kod wyjscia instalatora: ' + $code)
            if ($code -ne 0 -and $code -ne 3010) {
                Say 'Jesli powyzej widac 403 / Zabroniony: sprawdz VPN/proxy lub inna zaufana siec.'
                Say 'Zachowaj zrzut komunikatu instalatora razem z logiem.'
            }
            return [pscustomobject]@{ Code = $code; Text = 'Instalator interaktywny: sprawdz komunikat w konsoli.'; TimedOut = $false }
        } finally { $installer.Dispose() }
    }
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.RedirectStandardInput = $true
    # WSL writes UTF-16 to redirected output on Windows.
    $psi.StandardOutputEncoding = [Text.Encoding]::Unicode
    $psi.StandardErrorEncoding = [Text.Encoding]::Unicode
    $p = New-Object Diagnostics.Process
    $p.StartInfo = $psi
    try {
        if (-not $p.Start()) { throw 'Nie udalo sie uruchomic wsl.exe.' }
        $p.StandardInput.Close()
        $outTask = $p.StandardOutput.ReadToEndAsync()
        $errTask = $p.StandardError.ReadToEndAsync()
        Say ('Czekaj na wynik (limit ' + $TimeoutSeconds + ' s)...')
        if (-not $p.WaitForExit($TimeoutSeconds * 1000)) {
            try { $p.Kill() } catch { }
            Say '[TIMEOUT] Przekroczono czas oczekiwania. Instalator podrzedny moze nadal pracowac.'
            Say 'Nie uruchamiaj kolejnej instalacji od razu. Sprawdz Windows Update / instalator, potem zrestartuj komputer.'
            return [pscustomobject]@{ Code = 1460; Text = 'TIMEOUT'; TimedOut = $true }
        }
        $output = ($outTask.GetAwaiter().GetResult() + "`r`n" + $errTask.GetAwaiter().GetResult()).Replace([string][char]0, '').Trim()
        if ($output) { Say $output }
        Say ('Kod wyjscia: ' + $p.ExitCode)
        return [pscustomobject]@{ Code = $p.ExitCode; Text = $output; TimedOut = $false }
    } finally { $p.Dispose() }
}

function Failure-Advice([string]$Text) {
    Say ''
    Say '[BLAD] Ten etap nie zakonczyl sie poprawnie. Nie zglaszam gotowosci.'
    if ($Text -match '(?i)403|forbidden|zabronion') {
        Say '403: serwer lub posrednik sieciowy odrzuca pobieranie; uprawnienia administratora nie usuwaja tej blokady.'
        Say 'Sprawdz polaczenie przez inna zaufana siec (np. hotspot). Jesli uzywasz VPN/proxy, sprawdz jego ustawienia.'
        Say 'W sieci firmowej popros administratora o sprawdzenie blokad Microsoft Store / GitHub.'
    }
    if ($Text -match '(?i)0x8007019e') {
        Say '0x8007019e: skladnik WSL nie jest aktywny. Zrestartuj Windows i uruchom ten BAT ponownie.'
    }
    if ($Text -match '(?i)0x80370102|0x80370114|HCS_E_HYPERV_NOT_INSTALLED') {
        Say 'Sprawdz wirtualizacje Intel VT-x / AMD SVM w UEFI/BIOS oraz uruchamianie hypervisora.'
        Say 'W maszynie wirtualnej wymagane moze byc udostepnienie wirtualizacji zagniezdzonej przez hosta.'
    }
    if ($Text -match '(?i)0x800f081f|0x800f0906') {
        Say 'Windows nie znalazl plikow skladnikow. Dokoncz Windows Update i sprawdz jego dostep do zrodel naprawy.'
    }
    Say 'Jesli pobieranie WSL nadal nie dziala: oficjalne wydania i instalator MSI:'
    Say 'https://github.com/microsoft/WSL/releases/latest'
    Say 'Wybierz MSI zgodny z architektura Windows (x64 albo ARM64), zainstaluj i uruchom ten BAT ponownie.'
    Say 'Jesli polecenie nie rozpoznaje opcji: sprawdz aktualizacje Windows i WSL.'
    Say 'Przekaz autorowi pelny log oraz wersje Windows z polecenia winver.'
}

function Invoke-Setup {
    Say '=== Docker / WSL2 SMART v3 - instalacja interaktywna ==='
    Say 'Sprawdzanie systemu, skladnikow Windows i WSL.'
    $os = Get-CimInstance Win32_OperatingSystem
    Say ('System: {0}; build {1}; architektura {2}' -f $os.Caption, $os.BuildNumber, $os.OSArchitecture)
    if ([int]$os.BuildNumber -lt 19041) {
        Say '[STOP] Ten skrypt wymaga Windows build 19041 lub nowszego. Zaktualizuj Windows.'
        return 1
    }
    if (Test-PendingRestart) { Restart-Advice; return 3010 }

    $computer = Get-CimInstance Win32_ComputerSystem
    $cpu = @(Get-CimInstance Win32_Processor)
    if (-not $computer.HypervisorPresent) {
        if (@($cpu | Where-Object { $_.VirtualizationFirmwareEnabled -eq $false }).Count -gt 0) {
            Say '[STOP] Windows raportuje wylaczona / niedostepna wirtualizacje sprzetowa.'
            Say 'Wlacz Intel Virtualization Technology (VT-x) lub AMD SVM w UEFI/BIOS.'
            Say 'Sprawdz tez Menedzer zadan > Wydajnosc > Procesor > Wirtualizacja.'
            Say 'Jesli to maszyna wirtualna, sprawdz wirtualizacje zagniezdzona na hoscie.'
            return 1
        }
    }
    $bcd = (& "$env:SystemRoot\System32\bcdedit.exe" /enum '{current}' 2>&1 | Out-String)
    $bcdCode = $LASTEXITCODE
    if ($bcdCode -eq 0 -and $bcd -match '(?im)^\s*hypervisorlaunchtype\s+Off\s*$') {
        Say '[STOP] W konfiguracji rozruchu hypervisorlaunchtype ma wartosc Off.'
        Say 'Aby wlaczyc hypervisor, wykonaj w CMD jako administrator:'
        Say 'bcdedit /set hypervisorlaunchtype auto'
        Restart-Advice
        return 1
    }
    if ($bcdCode -ne 0) { Say '[UWAGA] Nie udalo sie odczytac konfiguracji rozruchu hypervisora.' }

    $restart = $false
    foreach ($name in @('VirtualMachinePlatform', 'Microsoft-Windows-Subsystem-Linux')) {
        $feature = Get-WindowsOptionalFeature -Online -FeatureName $name
        Say ('Skladnik {0}: {1}' -f $name, $feature.State)
        if ([string]$feature.State -match 'Pending') { $restart = $true; continue }
        if ([string]$feature.State -ne 'Enabled') {
            Say ('Wlaczanie ' + $name + ' ...')
            $result = Enable-WindowsOptionalFeature -Online -FeatureName $name -All -NoRestart
            if ($result.RestartNeeded) { $restart = $true }
            $after = Get-WindowsOptionalFeature -Online -FeatureName $name
            if ([string]$after.State -match 'Pending') { $restart = $true }
            elseif ([string]$after.State -ne 'Enabled') { throw ('Skladnik nie zostal wlaczony: ' + $name + '; stan: ' + $after.State) }
        }
    }
    if ($restart -or (Test-PendingRestart)) { Restart-Advice; return 3010 }

    if (-not (Test-Path "$env:SystemRoot\System32\wsl.exe")) {
        throw 'Brak wsl.exe po wlaczeniu skladnikow. Zrestartuj Windows i sprawdz Windows Update.'
    }
    $version = Invoke-Wsl -Arguments @('--version') -TimeoutSeconds 60
    if ($version.TimedOut) { return 1 }
    if ($version.Code -eq 0) {
        $action = @('--update')
    } else {
        Say 'Nie potwierdzono nowej wersji WSL. Proba instalacji bez dystrybucji Linux.'
        $action = @('--install', '--no-distribution')
    }
    $result = Invoke-Wsl -Arguments $action
    if ($result.TimedOut) { return 1 }
    if ($result.Code -eq 3010 -or (Test-PendingRestart)) { Restart-Advice; return 3010 }
    if ($result.Code -ne 0) {
        Say 'Pierwsza metoda nie powiodla sie. Probuje pobierania z --web-download.'
        $firstError = $result.Text
        $result = Invoke-Wsl -Arguments ($action + @('--web-download'))
        if ($result.TimedOut) { return 1 }
        if ($result.Code -eq 3010 -or (Test-PendingRestart)) { Restart-Advice; return 3010 }
        if ($result.Code -ne 0) { Failure-Advice ($firstError + "`n" + $result.Text); return 1 }
    }
    foreach ($check in @('--set-default-version', '--version', '--status')) {
        $arguments = @($check)
        if ($check -eq '--set-default-version') { $arguments += '2' }
        $result = Invoke-Wsl -Arguments $arguments -TimeoutSeconds 60
        if ($result.TimedOut) { return 1 }
        if ($result.Code -eq 3010 -or (Test-PendingRestart)) { Restart-Advice; return 3010 }
        if ($result.Code -ne 0) { Failure-Advice $result.Text; return 1 }
    }
    Say ''
    Say '[OK] Skladniki Windows wlaczone; polecenia aktualizacji/instalacji i kontroli WSL zakonczyly sie poprawnie.'
    Say 'Domyslna wersja dla nowych dystrybucji: WSL 2.'
    Say 'Nastepny krok: uruchom Docker Desktop i wybierz silnik WSL 2 w jego ustawieniach.'
    Say 'Skrypt nie testuje uruchomienia kontenera ani wymagan konkretnej wersji Docker Desktop.'
    Say 'Istniejace dystrybucje WSL 1 nie sa automatycznie konwertowane.'
    return 0
}

# ENTRY_POINT
if (-not (Test-Admin)) {
    Say 'Potrzebne uprawnienia administratora. Potwierdz okno UAC.'
    # Encode the command, so spaces, apostrophes and shell metacharacters in the path are safe.
    $literal = $env:WSL_SETUP_SELF.Replace("'", "''")
    $command = "`$env:WSL_SETUP_SELF='$literal'; `$s=[IO.File]::ReadAllText(`$env:WSL_SETUP_SELF); `$m='#'+' POWERSHELL_PAYLOAD'; & ([scriptblock]::Create(`$s.Substring(`$s.IndexOf(`$m)+`$m.Length)))"
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
    try {
        $child = Start-Process -FilePath "$PSHOME\powershell.exe" -ArgumentList @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand',$encoded) -Verb RunAs -Wait -PassThru
        exit $child.ExitCode
    } catch {
        Say ('Nie uzyskano uprawnien administratora: ' + $_.Exception.Message)
        exit 1
    }
}

$transcriptStarted = $false
$exitCode = 1
try {
    $logDir = Join-Path $env:LOCALAPPDATA 'DockerWSL2Setup\Logs'
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    $logPath = Join-Path $logDir ('setup-{0}-{1}.log' -f (Get-Date -Format 'yyyyMMdd-HHmmss'), $PID)
    Start-Transcript -Path $logPath -Force | Out-Null
    $transcriptStarted = $true
    Say ('Log: ' + $logPath)
    $exitCode = Invoke-Setup
} catch {
    Say ('[BLAD] ' + $_.Exception.Message)
    Failure-Advice ($_ | Out-String)
    $exitCode = 1
} finally {
    if ($transcriptStarted) {
        Say ('Log do diagnostyki: ' + $logPath)
        Stop-Transcript | Out-Null
    }
}
Say ''
Say ('Wynik: ' + $exitCode + ' (0 = gotowe, 3010 = wymagany restart, 1 = blad).')
Read-Host 'Nacisnij Enter, aby zamknac' | Out-Null
exit $exitCode
